-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: formazione_dipendenti
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `erogazione`
--

DROP TABLE IF EXISTS `erogazione`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `erogazione` (
  `ID_Erogazione` varchar(10) NOT NULL,
  `ID_Corso` varchar(10) NOT NULL,
  `ID_Docente` varchar(10) NOT NULL,
  `Data_Erogazione` date NOT NULL,
  PRIMARY KEY (`ID_Erogazione`),
  KEY `ID_Corso` (`ID_Corso`),
  KEY `ID_Docente` (`ID_Docente`),
  CONSTRAINT `erogazione_ibfk_1` FOREIGN KEY (`ID_Corso`) REFERENCES `corso` (`ID_Corso`),
  CONSTRAINT `erogazione_ibfk_2` FOREIGN KEY (`ID_Docente`) REFERENCES `docente` (`ID_Docente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `erogazione`
--

LOCK TABLES `erogazione` WRITE;
/*!40000 ALTER TABLE `erogazione` DISABLE KEYS */;
INSERT INTO `erogazione` VALUES ('ER001','C001','DOC_01','2023-01-13'),('ER002','C002','DOC_02','2023-01-23'),('ER003','C003','DOC_03','2023-02-09'),('ER004','C004','DOC_04','2023-03-20'),('ER005','C005','DOC_05','2023-06-13'),('ER006','C006','DOC_06','2023-10-17'),('ER007','C007','DOC_07','2023-11-08'),('ER008','C008','DOC_08','2023-11-21'),('ER009','C009','DOC_09','2023-12-07'),('ER010','C010','DOC_10','2024-01-19'),('ER011','C011','DOC_11','2024-03-05'),('ER012','C012','DOC_12','2024-06-24'),('ER013','C013','DOC_13','2024-07-23'),('ER014','C014','DOC_14','2024-07-26'),('ER015','C015','DOC_15','2024-10-16'),('ER016','C016','DOC_16','2024-12-18');
/*!40000 ALTER TABLE `erogazione` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-07 22:30:46
