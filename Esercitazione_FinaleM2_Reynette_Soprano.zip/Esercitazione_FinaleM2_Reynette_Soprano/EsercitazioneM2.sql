CREATE DATABASE EsercitazioneM2;

USE esercitazioneM2;

CREATE TABLE Product
(ProductID INT PRIMARY KEY,
CategoryID INT,
ProductName VARCHAR (50),
ListPrice DECIMAL (7,2)
);

CREATE TABLE Category
(CategoryID INT PRIMARY KEY,
CategoryName VARCHAR (50)
);

CREATE TABLE Sales
(SalesID INT PRIMARY KEY,
ProductID INT,
SalesDate DATE,
StateID INT
);

CREATE TABLE State
(StateID INT PRIMARY KEY,
StateName VARCHAR (50),
RegionID INT
);

CREATE TABLE Region
(RegionID INT PRIMARY KEY,
RegionName VARCHAR (50)
);

INSERT INTO 
Product
VALUES
(1, 1, 'Teddy Bear Small', 10.99);

SELECT
*
FROM
Product;

INSERT INTO
Product
VALUES
(2, 1, 'Stuffed Dinosaur', 15.99);

INSERT INTO
Product
VALUES
(4, 2, 'Remote Control Car', 29.99),
(9, 3, 'Castle Construction Set', 29.99),
(14, 5, 'Math Learning Kit', 18.99),
(20, 8, 'Musical Drum Set', 34.99);

SELECT
*
FROM
Product;

INSERT INTO
Category
VALUES
(1, 'Plush Toys'),
(2, 'Remote Control Toys'),
(3, 'Building Sets'),
(5, 'Educational Toys'),
(8, 'Musical Toys');

SELECT
*
FROM
Category;

ALTER TABLE
Product
ADD CONSTRAINT FOREIGN KEY
(CategoryID)
REFERENCES
Category (CategoryID);

INSERT INTO
Sales
VALUES
(652, 1, '2023-12-20', 1);

INSERT INTO
Sales
VALUES
(653, 1, '2023-12-21', 2),
(654, 2, '2023-12-22', 3),
(655, 2, '2023-12-23', 4),
(657, 4, '2023-12-25', 3),
(662, 9, '2023-12-30', 1),
(667, 14, '2024-01-04', 4),
(669, 20, '2024-01-06', 1);

SELECT
*
FROM
Sales;

INSERT INTO
State
VALUES
(1, 'France', 1);

INSERT INTO
State
VALUES
(2, 'Germany', 1),
(3, 'Italy', 2),
(4, 'Greece', 2);

SELECT
*
FROM
State;

INSERT INTO
Region
VALUES
(1, 'West Europe'),
(2, 'South Europe'),
(3, 'North America'),
(4, 'Asia Pacific');

SELECT
*
FROM
Region;

ALTER TABLE
Sales
ADD CONSTRAINT FOREIGN KEY
(ProductID)
REFERENCES
Product (ProductID);

ALTER TABLE
Sales
ADD CONSTRAINT FOREIGN KEY
(StateID)
REFERENCES
State (StateID);

ALTER TABLE
State
ADD CONSTRAINT FOREIGN KEY
(RegionID)
REFERENCES
Region (RegionID);

SELECT ProductID, COUNT(*)
FROM product
GROUP BY ProductID
HAVING COUNT(*) > 1;

SELECT CategoryID, COUNT(*)
FROM category
GROUP BY CategoryID
HAVING COUNT(*) > 1;

SELECT SalesID, COUNT(*)
FROM sales
GROUP BY SalesID
HAVING COUNT(*) > 1;

SELECT StateID, COUNT(*)
FROM state
GROUP BY StateID
HAVING COUNT(*) > 1;

SELECT RegionID, COUNT(*)
FROM region
GROUP BY RegionID
HAVING COUNT(*) > 1;

SELECT 
    s.SalesID AS DocumentCode,
    s.SalesDate,
    p.ProductName,
    c.CategoryName,
    st.StateName,
    r.RegionName,
    CASE
        WHEN DATEDIFF(CURDATE(), s.SalesDate) > 180 THEN TRUE
        ELSE FALSE
    END AS IsMoreThan180Days
FROM 
    Sales s
JOIN 
    Product p ON s.ProductID = p.ProductID
JOIN 
    Category c ON p.CategoryID = c.CategoryID
JOIN 
    State st ON s.StateID = st.StateID
JOIN 
    Region r ON st.RegionID = r.RegionID;










